/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

import java.util.*;
class Array {
    public static void main(String[] args) {
        int a[]={1,423,6,46,34,23,13,53,4};
           
          
        Arrays.sort(a);
       
        System.out.println("min-"+a[0]+" max-"+a[a.length-1]);
    }
}
