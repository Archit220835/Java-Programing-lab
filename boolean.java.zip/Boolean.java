public class Boolean

{
    public static void main(String[] args){
        Integer a=new Integer(5);
        int i=16;
        Integer j=i;
        System.out.println(a+""+i+""+" "+j);
        
    }
}





