/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class Array
{
	public static void main(String[] args)
	{
	    int size;
	    Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		size=sc.nextInt();
		int a[]=new int[size];
		for(int i=0;i<size;i++){
		     a[i]=i;
		    	System.out.println(a[i]);
		}
	}
}
